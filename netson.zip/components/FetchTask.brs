sub init()
    m.top.functionName = "fetchVideos"
end sub

sub fetchVideos()
    http = CreateObject("roUrlTransfer")
    http.SetUrl(m.top.url)
    http.SetCertificatesFile("common:/certs/ca-bundle.crt")
    http.InitClientCertificates()
    http.EnableEncodings(true)
    http.AddHeader("Accept", "application/json")
    http.RetainBodyOnError(true)

    port = CreateObject("roMessagePort")
    http.SetMessagePort(port)

    if not http.AsyncGetToString() then
        m.top.error = "Could not start the request to " + m.top.url
        return
    end if

    msg = wait(20000, port)
    if msg = invalid then
        http.AsyncCancel()
        m.top.error = "Request timed out"
        return
    end if

    code = msg.GetResponseCode()
    if code <> 200 then
        m.top.error = "Server returned HTTP " + code.toStr()
        return
    end if

    json = ParseJson(msg.GetString())
    if json = invalid then
        m.top.error = "The response was not valid JSON"
        return
    end if

    entries = extractList(json)

    content = CreateObject("roSGNode", "ContentNode")
    seenFields = ""

    for each item in entries
        if type(item) = "roAssociativeArray" then
            if seenFields = "" then seenFields = keyList(item)

            videoUrl = pick(item, ["videoUrl", "video_url", "videoURL", "url", "video", "link", "src", "source", "stream", "streamUrl", "stream_url", "mp4", "file", "videoLink", "video_link"])
            if videoUrl <> "" then
                thumb = pick(item, ["thumbnail", "thumbnailUrl", "thumbnail_url", "thumbnailURL", "thumb", "thumbUrl", "thumb_url", "poster", "cover", "preview", "previewImage", "imageUrl", "image_url", "image"])
                title = pick(item, ["title", "name", "videoTitle", "video_title", "caption"])
                desc = pick(item, ["description", "desc", "about", "details"])
                cr = getCreator(item)

                child = content.createChild("ContentNode")
                if title = "" then title = "Untitled"
                child.title = title
                child.url = videoUrl
                child.HDPosterUrl = thumb
                child.description = desc
                child.addFields({ creator: cr.name, avatar: cr.avatar })
            end if
        end if
    end for

    if content.getChildCount() = 0 then
        m.top.error = "No playable videos found in the response." + Chr(10) + "Fields seen: " + seenFields
        return
    end if

    m.top.content = content
end sub

' Finds the array/collection of videos in whatever JSON shape the PHP returns
function extractList(json as object) as object
    if type(json) = "roArray" then return json

    result = []
    if type(json) <> "roAssociativeArray" then return result

    ' Wrapped: {"videos": [...]} or {"data": {...}}
    for each k in ["videos", "data", "items", "results", "posts", "feed", "list"]
        if json.doesExist(k) then
            v = json[k]
            if type(v) = "roArray" or type(v) = "roAssociativeArray" then
                return extractList(v)
            end if
        end if
    end for

    ' A single video object
    if pick(json, ["videoUrl", "video_url", "videoURL", "url", "video", "link", "src"]) <> "" then
        return [json]
    end if

    ' Firebase style: { "-Nabc123": {...}, "-Nabc124": {...} }
    for each k in json
        v = json[k]
        if type(v) = "roAssociativeArray" then result.push(v)
    end for
    return result
end function

' Returns the first non-empty string found under any of the given keys
function pick(item as object, keys as object) as string
    for each k in keys
        if item.doesExist(k) then
            v = item[k]
            if GetInterface(v, "ifString") <> invalid then
                s = v.Trim()
                if s <> "" then return s
            else if type(v) = "roAssociativeArray" then
                s = pick(v, ["url", "src", "link", "original", "large", "medium"])
                if s <> "" then return s
            end if
        end if
    end for
    return ""
end function

' Creator may be a string or an object like {name, avatar}
function getCreator(item as object) as object
    result = { name: "", avatar: "" }
    avatarKeys = ["creatorImage", "creator_image", "creatorAvatar", "creator_avatar", "avatar", "avatarUrl", "avatar_url", "profileImage", "profile_image", "profilePic", "profile_pic", "pfp", "userImage", "user_image", "authorImage", "author_image", "creatorPhoto", "photo", "profile", "picture"]

    for each k in ["creator", "creatorName", "creator_name", "author", "authorName", "author_name", "uploader", "username", "userName", "user", "channel", "channelName", "owner", "artist", "by"]
        if item.doesExist(k) and result.name = "" then
            v = item[k]
            if GetInterface(v, "ifString") <> invalid then
                result.name = v.Trim()
            else if type(v) = "roAssociativeArray" then
                result.name = pick(v, ["name", "displayName", "display_name", "username", "userName", "handle", "title"])
                result.avatar = pick(v, avatarKeys + ["image"])
            end if
        end if
    end for

    if result.avatar = "" then result.avatar = pick(item, avatarKeys)

    ' If a separate thumbnail exists, a leftover "image" field is most likely the creator's picture
    if result.avatar = "" then
        thumbKeys = ["thumbnail", "thumbnailUrl", "thumbnail_url", "thumb", "thumbUrl", "poster", "cover", "preview"]
        if pick(item, thumbKeys) <> "" then result.avatar = pick(item, ["image", "imageUrl", "image_url"])
    end if

    return result
end function

function keyList(item as object) as string
    s = ""
    for each k in item
        if s <> "" then s = s + ", "
        s = s + k
    end for
    return s
end function
