sub onContentSet()
    c = m.top.itemContent
    if c = invalid then return

    m.top.findNode("thumb").uri = c.HDPosterUrl
    m.top.findNode("title").text = c.title

    avatar = m.top.findNode("avatar")
    creator = m.top.findNode("creator")

    name = ""
    av = ""
    if c.hasField("creator") then name = c.creator
    if c.hasField("avatar") then av = c.avatar

    creator.text = name
    if av <> "" then
        avatar.uri = av
        avatar.visible = true
        creator.translation = [36, 203]
        creator.width = 254
    else
        avatar.visible = false
        creator.translation = [0, 203]
        creator.width = 290
    end if
end sub
