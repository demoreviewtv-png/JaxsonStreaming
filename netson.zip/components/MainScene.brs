sub init()
    m.feedUrl = "https://netson.vercel.app/grab.php"

    m.grid = m.top.findNode("grid")
    m.status = m.top.findNode("statusLabel")
    m.countLabel = m.top.findNode("countLabel")
    m.footer = m.top.findNode("footerLabel")
    m.player = m.top.findNode("player")

    m.total = 0

    m.grid.observeField("itemFocused", "onItemFocused")
    m.grid.observeField("itemSelected", "onItemSelected")
    m.player.observeField("state", "onPlayerState")

    loadVideos()
end sub

sub loadVideos()
    m.grid.visible = false
    m.countLabel.text = ""
    m.footer.text = ""
    m.status.text = "Loading videos..."
    m.status.visible = true

    m.task = CreateObject("roSGNode", "FetchTask")
    m.task.url = m.feedUrl
    m.task.observeField("content", "onContent")
    m.task.observeField("error", "onError")
    m.task.control = "RUN"
end sub

sub onContent()
    content = m.task.content
    if content = invalid then return

    m.total = content.getChildCount()
    m.grid.content = content
    m.grid.visible = true
    m.status.visible = false
    m.countLabel.text = m.total.toStr() + " videos"
    m.grid.setFocus(true)
    updateFooter(0)
end sub

sub onError()
    msg = m.task.error
    if msg = invalid or msg = "" then return
    m.grid.visible = false
    m.status.text = msg + Chr(10) + Chr(10) + "Press * to retry"
    m.status.visible = true
end sub

sub onItemFocused()
    updateFooter(m.grid.itemFocused)
end sub

sub updateFooter(idx as integer)
    if m.total = 0 then return
    row = Int(idx / 4) + 1
    totalRows = Int((m.total + 3) / 4)
    m.footer.text = "Video " + (idx + 1).toStr() + " of " + m.total.toStr() + "   |   Row " + row.toStr() + " of " + totalRows.toStr()
end sub

sub onItemSelected()
    idx = m.grid.itemSelected
    child = m.grid.content.getChild(idx)
    if child = invalid then return
    if child.url = invalid or child.url = "" then return

    vc = CreateObject("roSGNode", "ContentNode")
    vc.url = child.url
    vc.title = child.title
    vc.streamFormat = detectFormat(child.url)

    m.player.content = vc
    m.player.visible = true
    m.player.setFocus(true)
    m.player.control = "play"
end sub

function detectFormat(url as string) as string
    u = LCase(url)
    if Instr(1, u, ".m3u8") > 0 then return "hls"
    if Instr(1, u, ".mpd") > 0 then return "dash"
    if Instr(1, u, ".mkv") > 0 or Instr(1, u, ".webm") > 0 then return "mkv"
    return "mp4"
end function

sub onPlayerState()
    state = m.player.state
    if state = "finished" then
        closePlayer()
    else if state = "error" then
        closePlayer()
        m.footer.text = "Playback error - that video could not be played"
    end if
end sub

sub closePlayer()
    m.player.control = "stop"
    m.player.visible = false
    m.grid.setFocus(true)
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false

    if m.player.visible then
        if key = "back" then
            closePlayer()
            return true
        end if
        return false
    end if

    if key = "options" then
        loadVideos()
        return true
    end if

    return false
end function
